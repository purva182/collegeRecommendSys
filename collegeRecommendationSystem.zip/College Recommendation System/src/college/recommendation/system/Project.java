package college.recommendation.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Project extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    Project() {
        setSize(1540, 850);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/third.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1500, 750, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        add(image);

        JMenuBar mb = new JMenuBar();

        // New Information
        JMenu student = new JMenu("Student");
        student.setForeground(Color.BLUE);
        mb.add(student);

        JMenuItem studentProfile = new JMenuItem("Student Profile");
        studentProfile.setBackground(Color.WHITE);
        studentProfile.addActionListener(this);
        student.add(studentProfile);

        // Details
        JMenu collegeList = new JMenu("College List");
        collegeList.setForeground(Color.RED);
        mb.add(collegeList);

        JMenuItem pune = new JMenuItem("Pune");
        pune.setBackground(Color.WHITE);
        pune.addActionListener(this);
        collegeList.add(pune);

        // Exams
        JMenu recommendation = new JMenu("Recommend");
        recommendation.setForeground(Color.BLUE);
        mb.add(recommendation);

        JMenuItem puneRecommendation = new JMenuItem("Pune College Recommendation");
        puneRecommendation.setBackground(Color.WHITE);
        puneRecommendation.addActionListener(this);
        recommendation.add(puneRecommendation);

        // Fee
        JMenu fee = new JMenu("Fee Details");
        fee.setForeground(Color.BLUE);
        mb.add(fee);

        JMenuItem feestructure = new JMenuItem("Fee Structure");
        feestructure.setBackground(Color.WHITE);
        feestructure.addActionListener(this);
        fee.add(feestructure);

        // View Profile
        JMenu viewProfileMenu = new JMenu("View Profile");
        viewProfileMenu.setForeground(Color.RED);
        mb.add(viewProfileMenu);

        JMenuItem viewProfileItem = new JMenuItem("View Profile");
        viewProfileItem.setBackground(Color.WHITE);
        viewProfileItem.addActionListener(this);
        viewProfileMenu.add(viewProfileItem);

        // About
        JMenu about = new JMenu("About");
        about.setForeground(Color.BLUE);
        mb.add(about);

        JMenuItem ab = new JMenuItem("About");
        ab.setBackground(Color.WHITE);
        ab.addActionListener(this);
        about.add(ab);

        // Exit
        JMenu exit = new JMenu("Exit");
        exit.setForeground(Color.RED);
        mb.add(exit);

        JMenuItem ex = new JMenuItem("Exit");
        ex.setBackground(Color.WHITE);
        ex.addActionListener(this);
        exit.add(ex);

        setJMenuBar(mb);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String msg = ae.getActionCommand();

        if (msg.equals("Exit")) {
            setVisible(false);
        } else if (msg.equals("Student Profile")) {
            // Display student profile (replace this with your logic)
            JOptionPane.showMessageDialog(this, "Displaying Student Profile");
        } else if (msg.equals("Pune")) {
            new Collegelist(this);
        } else if (msg.equals("Pune College Recommendation")) {
            new Recommend(this).setVisible(true); // Set Recommend frame visible
        } else if (msg.equals("Fee Structure")) {
            new FeeStructure().setVisible(true);
        } else if (msg.equals("About")) {
            new About();
        }
    }

    public static void main(String[] args) {
        new Project();
    }
}
