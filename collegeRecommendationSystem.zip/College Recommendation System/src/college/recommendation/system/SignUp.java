package college.recommendation.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class SignUp extends JFrame implements ActionListener{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton login, cancel, signUp;
    JTextField tfusername, tfpassword, tfcpassword;
    
     SignUp() {
        
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        JLabel lblusername = new JLabel("Username");
        lblusername.setBounds(40, 20, 100, 20);
        add(lblusername);
        
        tfusername = new JTextField();
        tfusername.setBounds(150, 20, 150, 20);
        add(tfusername);
        
        JLabel lblpassword = new JLabel("Password");
        lblpassword.setBounds(40, 70, 100, 20);
        add(lblpassword);
        
        tfpassword = new JPasswordField();
        tfpassword.setBounds(150, 70, 150, 20);
        add(tfpassword);
        
        JLabel lblcpassword = new JLabel("Confirm Password");
        lblcpassword.setBounds(40, 120, 120, 20);
        add(lblcpassword);
        
        tfcpassword = new JPasswordField();
        tfcpassword.setBounds(150, 120, 150, 20);
        add(tfcpassword);

        
        signUp = new JButton("Sign Up");
        signUp.setBounds(110, 180, 120, 30);
        signUp.setBackground(Color.BLACK);
        signUp.setForeground(Color.WHITE);
        signUp.addActionListener(this);
        signUp.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(signUp);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/second.jpg"));
        Image i2 = i1.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(350, 0, 200, 200);
        add(image);
        
        setSize(600, 300);
        setLocation(500, 250);
        setVisible(true);
    }
     @Override
     public void actionPerformed(ActionEvent e) {
         if (e.getSource() == signUp) {
             String username = tfusername.getText().trim();
             String password = tfpassword.getText().trim();
             String confirmPassword = tfcpassword.getText().trim();
             
             String q = "SELECT * FROM users WHERE username = '" + username + "'";
             String q1 = "INSERT INTO users (username, password) VALUES ('" + username + "', '" + password + "')";

             // Check if passwords match
             if (!password.equals(confirmPassword)) {
                 JOptionPane.showMessageDialog(this, "Passwords do not match", "Error", JOptionPane.ERROR_MESSAGE);
                 return;
             }

             // Establish database connection and execute query
             try {
                 Conn c = new Conn();
                 ResultSet rs = c.s.executeQuery(q);

                 // Check if username exists
                 if (rs.next()) {
                     JOptionPane.showMessageDialog(this, "Username already exists", "Error", JOptionPane.ERROR_MESSAGE);
                     return;
                 }

                 // Insert new username and password
                 int result = c.s.executeUpdate(q1);
                 if (result > 0) {
                     JOptionPane.showMessageDialog(this, "Account Created Successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                     dispose(); // Close the sign-up window

                     // Open the login window
                     new Login();
                 } else {
                     JOptionPane.showMessageDialog(this, "Failed to create account", "Error", JOptionPane.ERROR_MESSAGE);
                 }

             } catch (SQLException ex) {
                 ex.printStackTrace();
                 JOptionPane.showMessageDialog(this, "Database error", "Error", JOptionPane.ERROR_MESSAGE);
             }
         }
     }
}