package college.recommendation.system;

import javax.swing.*;
import java.awt.*;

public class About extends JFrame {

    private static final long serialVersionUID = 1L;

	About() {
        setSize(700, 500);
        setLocation(400, 150);
        getContentPane().setBackground(Color.WHITE);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/about.jpg"));
        Image i2 = i1.getImage().getScaledInstance(300, 200, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(350, 0, 300, 200);
        add(image);
        
        JLabel heading = new JLabel("<html>College<br/>Recommendation System</html>");
        heading.setBounds(70, 20, 300, 130);
        heading.setFont(new Font("Tahoma", Font.BOLD, 30));
        add(heading);
        
        JLabel name = new JLabel("Developed By: SY CSAI Group 05");
        name.setBounds(70, 220, 550, 40);
        name.setFont(new Font("Tahoma", Font.BOLD, 30));
        add(name);
        
        JLabel t1 = new JLabel("1.Devang Bissa");
        t1.setBounds(70, 250, 550, 40);
        t1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(t1);
        
        JLabel t2 = new JLabel("2.Purva Golegaonkar");
        t2.setBounds(70, 270, 550, 40);
        t2.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(t2);
        
        JLabel t3 = new JLabel("3.Tanmay Bora");
        t3.setBounds(70, 290, 550, 40);
        t3.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(t3);
        
        JLabel t4 = new JLabel("4.Ishawar Borade");
        t4.setBounds(70, 310, 550, 40);
        t4.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(t4);
        
        setLayout(null);
        
        setVisible(true);
    }
    
    public static void main(String[] args) {
        new About();
    }
}
