package college.recommendation.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StudentProfile extends JFrame implements ActionListener {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton btnSave, btnCancel, btnUpdate, btnDelete, btnViewProfile;
    JTextField tfStudentId, tfName, tfDateOfBirth, tfAge, tfEmail, tfRegistrationDate;
    JComboBox<String> cbCaste;

    public StudentProfile() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel lblStudentId = new JLabel("Student ID");
        lblStudentId.setBounds(40, 20, 100, 20);
        add(lblStudentId);

        tfStudentId = new JTextField();
        tfStudentId.setBounds(150, 20, 150, 20);
        add(tfStudentId);

        JLabel lblName = new JLabel("Name");
        lblName.setBounds(40, 50, 100, 20);
        add(lblName);

        tfName = new JTextField();
        tfName.setBounds(150, 50, 150, 20);
        add(tfName);

        JLabel lblDateOfBirth = new JLabel("Date of Birth");
        lblDateOfBirth.setBounds(40, 80, 100, 20);
        add(lblDateOfBirth);

        tfDateOfBirth = new JTextField();
        tfDateOfBirth.setBounds(150, 80, 150, 20);
        add(tfDateOfBirth);

        JLabel lblAge = new JLabel("Age");
        lblAge.setBounds(40, 110, 100, 20);
        add(lblAge);

        tfAge = new JTextField();
        tfAge.setBounds(150, 110, 150, 20);
        add(tfAge);

        JLabel lblEmail = new JLabel("Email");
        lblEmail.setBounds(40, 140, 100, 20);
        add(lblEmail);

        tfEmail = new JTextField();
        tfEmail.setBounds(150, 140, 150, 20);
        add(tfEmail);

        JLabel lblRegistrationDate = new JLabel("Registration Date");
        lblRegistrationDate.setBounds(40, 170, 100, 20);
        add(lblRegistrationDate);

        tfRegistrationDate = new JTextField();
        tfRegistrationDate.setBounds(150, 170, 150, 20);
        add(tfRegistrationDate);

        JLabel lblCaste = new JLabel("Caste");
        lblCaste.setBounds(40, 200, 100, 20);
        add(lblCaste);

        cbCaste = new JComboBox<>(new String[]{"General", "OBC", "SC", "ST", "Other"});
        cbCaste.setBounds(150, 200, 150, 20);
        add(cbCaste);

        btnSave = new JButton("Save");
        btnSave.setBounds(40, 240, 120, 30);
        btnSave.setBackground(Color.BLACK);
        btnSave.setForeground(Color.WHITE);
        btnSave.addActionListener(this);
        btnSave.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(btnSave);

        btnCancel = new JButton("Cancel");
        btnCancel.setBounds(180, 240, 120, 30);
        btnCancel.setBackground(Color.BLACK);
        btnCancel.setForeground(Color.WHITE);
        btnCancel.addActionListener(this);
        btnCancel.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(btnCancel);

        btnUpdate = new JButton("Update");
        btnUpdate.setBounds(40, 280, 120, 30);
        btnUpdate.setBackground(Color.BLACK);
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.addActionListener(this);
        btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(btnUpdate);

        btnDelete = new JButton("Delete");
        btnDelete.setBounds(180, 280, 120, 30);
        btnDelete.setBackground(Color.BLACK);
        btnDelete.setForeground(Color.WHITE);
        btnDelete.addActionListener(this);
        btnDelete.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(btnDelete);

        btnViewProfile = new JButton("View Profile");
        btnViewProfile.setBounds(40, 320, 260, 30);
        btnViewProfile.setBackground(Color.BLACK);
        btnViewProfile.setForeground(Color.WHITE);
        btnViewProfile.addActionListener(this);
        btnViewProfile.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(btnViewProfile);

        setSize(400, 380);
        setLocation(500, 250);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnSave) {
            saveStudentProfile();
        } else if (ae.getSource() == btnCancel) {
            setVisible(false);
        } else if (ae.getSource() == btnUpdate) {
            updateStudentProfile();
        } else if (ae.getSource() == btnDelete) {
            deleteStudentProfile();
        } else if (ae.getSource() == btnViewProfile) {
            viewStudentProfile();
        }
    }

    private void saveStudentProfile() {
    	int studentId = Integer.parseInt(tfStudentId.getText());
        String name = tfName.getText();
        String dateOfBirth = tfDateOfBirth.getText();
        int age = Integer.parseInt(tfAge.getText());
        String email = tfEmail.getText();
        String registrationDate = tfRegistrationDate.getText();
        String caste = (String) cbCaste.getSelectedItem();

        String JDBC_URL = "jdbc:mysql://localhost:3306/college_recommend";
        String USERNAME = "root";
        String PASSWORD = "18122003";

        try {
            Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            String sql = "INSERT INTO stud (studentId, name, dateofBirth, age, email, registrationDate, caste) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, studentId);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, dateOfBirth);
            preparedStatement.setInt(4, age);
            preparedStatement.setString(5, email);
            preparedStatement.setString(6, registrationDate);
            preparedStatement.setString(7, caste);

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Student profile saved successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to save student profile.");
            }

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while saving the student profile.");
        }

    }

    private void updateStudentProfile() {
    	  int studentId = Integer.parseInt(tfStudentId.getText());
          String name = tfName.getText();
          String dateOfBirth = tfDateOfBirth.getText();
          int age = Integer.parseInt(tfAge.getText());
          String email = tfEmail.getText();
          String registrationDate = tfRegistrationDate.getText();
          String caste = (String) cbCaste.getSelectedItem();

          String JDBC_URL = "jdbc:mysql://localhost:3306/college_recommend";
          String USERNAME = "root";
          String PASSWORD = "18122003";

          try {
              Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
              String sql = "UPDATE stud SET name=?, dateofBirth=?, age=?, email=?, registrationDate=?, caste=? WHERE studentId=?";
              PreparedStatement preparedStatement = connection.prepareStatement(sql);

              preparedStatement.setString(1, name);
              preparedStatement.setString(2, dateOfBirth);
              preparedStatement.setInt(3, age);
              preparedStatement.setString(4, email);
              preparedStatement.setString(5, registrationDate);
              preparedStatement.setString(6, caste);
              preparedStatement.setInt(7, studentId);

              int rowsUpdated = preparedStatement.executeUpdate();
              if (rowsUpdated > 0) {
                  JOptionPane.showMessageDialog(this, "Student profile updated successfully.");
              } else {
                  JOptionPane.showMessageDialog(this, "Failed to update student profile.");
              }

              preparedStatement.close();
              connection.close();
          } catch (SQLException e) {
              e.printStackTrace();
              JOptionPane.showMessageDialog(this, "An error occurred while updating the student profile.");
          }

    }

    private void deleteStudentProfile() {
    	int studentId = Integer.parseInt(tfStudentId.getText());

        String JDBC_URL = "jdbc:mysql://localhost:3306/college_recommend";
        String USERNAME = "root";
        String PASSWORD = "18122003";

        try {
            Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            String sql = "DELETE FROM stud WHERE studentId=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, studentId);

            int rowsDeleted = preparedStatement.executeUpdate();
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(this, "Student profile deleted successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete student profile.");
            }

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while deleting the student profile.");
        }


    }

    private void viewStudentProfile() {
        int studentId = Integer.parseInt(tfStudentId.getText());

        String JDBC_URL = "jdbc:mysql://localhost:3306/college_recommend";
        String USERNAME = "root";
        String PASSWORD = "18122003";

        try {
            Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            String sql = "SELECT * FROM stud WHERE studentId=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, studentId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                // Populate the text fields with the retrieved data
                tfName.setText(resultSet.getString("name"));
                tfDateOfBirth.setText(resultSet.getString("dateofBirth"));
                tfAge.setText(String.valueOf(resultSet.getInt("age")));
                tfEmail.setText(resultSet.getString("email"));
                tfRegistrationDate.setText(resultSet.getString("registrationDate"));
                cbCaste.setSelectedItem(resultSet.getString("caste"));
            } else {
                JOptionPane.showMessageDialog(this, "Student profile not found.");
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while viewing the student profile.");
        }
    }


    public static void main(String[] args) {
        new StudentProfile();
    }
}
