package college.recommendation.system;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class Recommend extends JFrame {

    private static final long serialVersionUID = 1L;
    private JComboBox<String> branchComboBox;
    private JTextField cutoffTextField;
    private JTable recommendationTable;

    public Recommend(JFrame previousFrame) {
        setTitle("College Recommendation System");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));

        JLabel branchLabel = new JLabel("Select Branch:");
        String[] branches = {"CS", "IT", "AIDS"};
        branchComboBox = new JComboBox<>(branches);
        branchComboBox.setPreferredSize(new Dimension(150, 25)); // Set preferred size

        JLabel cutoffLabel = new JLabel("Enter CET Score (Percentile):");
        cutoffTextField = new JTextField();
        cutoffTextField.setPreferredSize(new Dimension(150, 25)); // Set preferred size

        JButton recommendButton = new JButton("Recommend");
        recommendButton.addActionListener(e -> recommendColleges());

        inputPanel.add(branchLabel);
        inputPanel.add(branchComboBox);
        inputPanel.add(cutoffLabel);
        inputPanel.add(cutoffTextField);
        inputPanel.add(recommendButton);

        add(inputPanel, BorderLayout.NORTH);

        recommendationTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(recommendationTable);
        add(scrollPane, BorderLayout.CENTER);

        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                previousFrame.setVisible(true); // Show the previous frame upon closing
            }
        });
    }

    private void recommendColleges() {
        String selectedBranch = (String) branchComboBox.getSelectedItem();
        String cutoffString = cutoffTextField.getText().trim();

        if (cutoffString.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter CET Percentile Cutoff.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double cutoff;
        try {
            cutoff = Double.parseDouble(cutoffString);
            if (cutoff < 0 || cutoff > 100) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid CET Percentile Cutoff. Please enter a number between 0 and 100.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("College Name");
        model.addColumn("Previous Year Score");

        try {
            Conn con = new Conn();
            // Call the stored procedure instead of direct SQL query
            String query = "{CALL  GetTopColleges(?, ?)}"; // Assuming college_prediction is the name of your stored procedure
            CallableStatement cstmt = con.c.prepareCall(query);
            cstmt.setString(1, selectedBranch);
            cstmt.setDouble(2, cutoff);
            ResultSet rs = cstmt.executeQuery();

            while (rs.next()) {
                String collegeName = rs.getString("College_name");
                double lastYearCutoff = rs.getDouble("cut_off_year_2");
                model.addRow(new Object[]{collegeName, lastYearCutoff});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "An error occurred while fetching data from the database.", "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }

        recommendationTable.setModel(model);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame previousFrame = new Project();
            previousFrame.setSize(600, 400);
            previousFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            previousFrame.setVisible(true);

            Recommend frame = new Recommend(previousFrame);
            frame.setVisible(true);
        });
    }
}
