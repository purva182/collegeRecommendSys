package college.recommendation.system;

import javax.swing.*;
import java.sql.*;

public class Collegelist extends JFrame {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String[][] data;
    private String[] columns = {"Serial No", "Code", "College Name", "Seat Intake", "Region", "Branch", "Cut-off Year 1", "Cut-off Year 2"};

    public Collegelist(JFrame previousFrame) {
        try {
            Conn con = new Conn();
            Statement stmt = con.c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

            // Modify the query to include the join between college_info and branch_info tables
            String query = "SELECT c.serial_no, c.Code, c.College_name, c.Seat_Intake, c.Region, b.branch_name, b.cut_off_year_1, b.cut_off_year_2 " +
                           "FROM college_info c " +
                           "INNER JOIN branch_info b ON c.serial_no = b.serial_no";
            ResultSet rs = stmt.executeQuery(query);

            // Get the number of rows in the ResultSet
            rs.last();
            int numRows = rs.getRow();
            rs.beforeFirst(); // Reset the cursor to the beginning

            // Initialize data array with the number of rows
            data = new String[numRows][8]; // Increase the column count to 8 for additional columns from the join

            // Populate data array from ResultSet
            int row = 0;
            while (rs.next()) {
                data[row][0] = rs.getString("serial_no");
                data[row][1] = rs.getString("Code");
                data[row][2] = rs.getString("College_name");
                data[row][3] = rs.getString("Seat_Intake");
                data[row][4] = rs.getString("Region");
                data[row][5] = rs.getString("branch_name");
                data[row][6] = rs.getString("cut_off_year_1");
                data[row][7] = rs.getString("cut_off_year_2");
                row++;
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        JTable jt = new JTable(data, columns);
        jt.setBounds(30, 40, 200, 300);
        JScrollPane sp = new JScrollPane(jt);
        add(sp);
        setSize(800, 400);
        setVisible(true);
        
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                previousFrame.setVisible(true); // Show the previous frame upon closing
            }
        });
    }

    public static void main(String[] args) {
        JFrame previousFrame = new Project();
        previousFrame.setSize(600, 400);
        previousFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        previousFrame.setVisible(true);
        new Collegelist(previousFrame);
    }
}
