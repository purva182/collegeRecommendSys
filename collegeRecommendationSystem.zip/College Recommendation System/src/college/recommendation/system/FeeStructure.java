package college.recommendation.system;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class FeeStructure extends JFrame implements ActionListener {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JComboBox<String> collegeDropdown;
    private JTable table;
    private Connection conn;

    FeeStructure() {
        setTitle("Fee Structure");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null); // Center the frame on the screen

        // Create components
        JPanel panel = new JPanel(new BorderLayout());
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JPanel centerPanel = new JPanel(new BorderLayout());
        JLabel heading = new JLabel("Fee Structure");
        heading.setFont(new Font("Tahoma", Font.BOLD, 24));
        collegeDropdown = new JComboBox<>();
        table = new JTable();

        // Styling components
        topPanel.setBackground(Color.WHITE);
        centerPanel.setBackground(Color.WHITE);
        heading.setForeground(Color.BLUE);

        // Add components to panels
        topPanel.add(heading);
        topPanel.add(new JLabel("Select College:"));
        topPanel.add(collegeDropdown);
        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        add(panel);

        // Establish database connection and populate college dropdown
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/college_recommend", "root", "18122003");
            PreparedStatement ps = conn.prepareStatement("SELECT college_name FROM college_fees");
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                collegeDropdown.addItem(rs.getString("college_name"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error connecting to database: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

        collegeDropdown.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == collegeDropdown) {
            try {
                String selectedCollege = (String) collegeDropdown.getSelectedItem();
                PreparedStatement ps = conn.prepareStatement("SELECT * FROM college_fees WHERE college_name = ?");
                ps.setString(1, selectedCollege);
                ResultSet rs = ps.executeQuery();

                // Populate JTable directly from ResultSet
                DefaultTableModel model = new DefaultTableModel();
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                
                // Set column names
                for (int i = 1; i <= columnCount; i++) {
                    model.addColumn(metaData.getColumnName(i));
                }

                // Populate table rows
                int serialNo = 1;
                while (rs.next()) {
                    Object[] rowData = new Object[columnCount];
                    rowData[0] = serialNo++; // Serial number
                    for (int i = 2; i <= columnCount; i++) {
                        rowData[i - 1] = rs.getObject(i);
                    }
                    model.addRow(rowData);
                }
                table.setModel(model);

                // Set column width for serial number column
                table.getColumnModel().getColumn(0).setPreferredWidth(50);
                table.getColumnModel().getColumn(0).setMaxWidth(50);

                // Set alignment for college name column
                DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
                centerRenderer.setHorizontalAlignment(JLabel.CENTER);
                table.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error executing query: " + ex.getMessage(), "Query Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        // Set look and feel to system default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        SwingUtilities.invokeLater(() -> new FeeStructure());
    }
}
